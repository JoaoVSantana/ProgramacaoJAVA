package model;

public class Pagamento {

	private String forma;
	private int parcelamento;
	private double desconto;
	private double precoTotal;
	private double frete;
	private Venda venda;
}
