package model;

public class Endereco {

	private String identificacao;
	private String rua;
	private String uf;
	private String cep;
	private String cidade;
	private String complemento;
}
