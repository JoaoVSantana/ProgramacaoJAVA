package model;

public class Venda {
	
	private Cliente cliente;
	private String empresa;
	private Produto produtos;

}
